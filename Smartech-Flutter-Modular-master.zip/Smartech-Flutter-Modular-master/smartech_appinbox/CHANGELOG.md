## 3.2.0

* Initial Release With Smartech AppInbox Android SDK v3.2.6.

## 3.2.1

* Added support for iOS platform.
* Converted JSON data of AppInbox to Model Classes for ease of usability.
* Updated Smartech AppInbox Android SDK v3.2.7.

## 3.2.2

* Updated model class for smtCustomPayload and smtPayload.

## 3.2.3

* Updated Smartech Appinbox iOS SDK v3.2.4.
* Updated Smartech Appinbox Android SDK v3.2.8.
* Updated model class for status value.

## 3.2.4

* Updated code for pull to refresh logic for android.
* Updated Smartech Appinbox Android SDK v3.2.10.

## 3.2.5

* Added support to manage SDK version from app level gradle.properties.

## 3.2.6

* Updated gradle version.

## 3.2.7

* Updated model class according to Push Notification payload.

## 3.2.8

* Added minimum support of Flutter SDK.
* Updated compileSDkVersion.
* Updated AppInbox Model class

## 3.2.9

* Updated the dependency intl package to 0.18.1