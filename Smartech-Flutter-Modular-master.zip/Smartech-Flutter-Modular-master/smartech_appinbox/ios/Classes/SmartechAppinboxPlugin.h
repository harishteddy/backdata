#import <Flutter/Flutter.h>

@interface SmartechAppinboxPlugin : NSObject<FlutterPlugin>
@end
