## 3.2.0

* Initial Release With Smartech Base Android SDK v3.2.9

## 3.2.1

* Added support for iOS platform. (SDK Version : v1.0.0)
* Updated Smartech Push Android SDK v3.2.11.

## 3.2.2

* Updated Smartech Push Android SDK v3.2.12.

## 3.2.3

* Updated Smartech Push iOS SDK v3.0.0.
* Updated Smartech Push Android SDK v3.2.14.

## 3.2.4

* Updated Smartech Push Android SDK v3.2.15.

## 3.2.5

* Added support to manage SDK version from app level gradle.properties.

## 3.2.6

* Fixed fetchAlreadyGeneratedToken method on flutter plugin.

## 3.2.7

* Updated gradle version.

## 3.2.8

* Added minimum support of Flutter SDK.
* Updated compileSDkVersion.
