#import <Flutter/Flutter.h>

@interface SmartechPushPlugin : NSObject<FlutterPlugin>
@end
