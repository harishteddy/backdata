//
//  NotificationViewController.h
//  SmartechNCE
//
//  Created by Shubham on 25/07/22.
//

#import <UIKit/UIKit.h>

@interface NotificationViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIView *customView;

@end
