#import <Flutter/Flutter.h>
#import <UIKit/UIKit.h>
#import <Smartech/Smartech.h>
#import <SmartPush/SmartPush.h>

@interface AppDelegate : FlutterAppDelegate

@end
