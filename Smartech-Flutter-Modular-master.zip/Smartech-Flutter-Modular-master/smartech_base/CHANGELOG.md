## 3.2.0

* Initial Release With Smartech Base Android SDK v3.2.19

## 3.2.1

* Added support for iOS platform. (SDK Version : v3.2.7)
* Updated Smartech Base Android SDK v3.2.20.

## 3.2.2

* Updated Smartech Base Android SDK v3.2.23.

## 3.2.3

* Updated Smartech Base Android SDK v3.2.26.

## 3.2.4

* Updated Smartech Base Android SDK v3.2.27.

## 3.2.5

* Added support to manage SDK version from app level gradle.properties.

## 3.2.6

* Updated gradle version.

## 3.2.7

* Exposed payload on click of Push Notification.

## 3.2.8

* Added minimum support of Flutter SDK.
* Updated compileSDkVersion.
