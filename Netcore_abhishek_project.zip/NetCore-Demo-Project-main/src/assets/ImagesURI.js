export const images = {
    Logo: require('../assets/images/Logo.png'),
    Guard: require('../assets/images/Guard.png'),
};