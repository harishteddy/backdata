import {StyleSheet} from 'react-native';

export default commonStyles = StyleSheet.create({
    container: {
      flex: 1
    }
    
});