export const WHITE_COLOR = "#FFFFFF";
export const BLACK_COLOR = "#000000";
export const RED_COLOR = "#FF0000";
export const GREEN_COLOR = "#006400";
export const BLUE_COLOR = "#0000FF";
const Colors = {
    primary: '#FFFFFF',
    secondary: '#000000',
    red: '#FF0000',
    green: '#006400',
    blue: '#0000FF',
  };
  
  export default Colors;
  