const strings = {
    home: {
      headerTitle: "Home",
      homeScreen: "Home Screen",
      next: "Next",
      networkScreen: 'NetworkScreen',
      googleLogin: 'GoogleLogin'
    },
    details: {
        detailsScreen: "Details Screen"
    }
}
  
export default strings;