package com.netcore.smarttechdemo

data class User (val id: Int = -1, val name: String, val password: String)